module.exports={
    db:'mongodb+srv://siyaa:siyaa@cluster0.g08f639.mongodb.net/MeanStack?retryWrites=true&w=majority'
};